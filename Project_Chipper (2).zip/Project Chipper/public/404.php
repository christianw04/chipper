<div class="container">
    <h1>404 Error</h1>
    <p>Page doesn't exist.</p>
</div>