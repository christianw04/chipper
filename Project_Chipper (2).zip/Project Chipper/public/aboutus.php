<!-- Main -->
<section id="main">
					<div class="container">

						<!-- Content -->
							<article class="box post" id="about">
								<a href="#" class="image featured"><img src="images/pic01.jpg" alt="" /></a>
								<header>
									<h2>About The Team</h2>
									<p>Donnie, Christian, Trevin, Trent, Megan and Zach</p>
								</header>
								<p>
									About <strong>Donnie</strong>. My name is Donnie Garrison. I am 24 years old, I am from Wheeling, WV, and I am currently pursuing an 
									Associate Degree in Software Engineering at WVNCC. Some of my favorite hobbies of my past time is attending 
									football and basketball games with my girlfriend, often they are Marshall University sporting events as I 
									visit her in Huntington as she attends Marshall down there. Another one of my favorite past times including
									sports is to watch and support my favorite NFL team the Pittsburgh Steelers. I also enjoy attending expos 
									such as reptile expos, curiosities/oddities expos, and crystals/minerals expos. If I have enough free time, 
									I love to binge-watch some tv shows, such as The Rookie, AHS, Kitchen Nightmares, and Next Level Chef 
									(I'm a big Gordon Ramsay). I enjoy all those things, however, my favorite activity to unwind and relax is 
									fishing. It is a great way for me to handle the stress that not just school, but life as well can compile 
									onto us all at some times. I believe it is important to always have outlets to 'get away' for a while, and 
									getting away for me is spending hours at a pond or lake with my line in the water. As far as the future 
									goes, there are plentiful opportunities in the ever-growing world of technology, so I'm not particularly 
									sure what career I may decide on. My plan is to take advantage of the internship that WVNCC offers in our 
									final semester and use that to possibly see where my path may continue.


									My task for Chipper: Beta Testing - Test every aspect of the code, and make sure that the functions are 
									efficient and work the way they are intended to. The QA Tester will attempt to "break" the code to discover
									bugs and share feedback with the group, as well as debug the issues found.
								</p>
								<p>
									About <strong>Christian</strong>. My name is Christian Waterman. I'm 21 years old and I'm from Indianapolis, IN but now I 
									live in Bridgeport, OH for the past 6 years. I'm currently pursuing my Associate Degree in Software 
									Engineering and I'm attending West Virginia Northern as a sophomore which means it's my second year here at 
									northern. What I usually do for fun or what I like to do for fun is play video games. Some of my favorite 
									video games at the moment are Valorant and Payday 3. I usually don't play video games unless my friends are 
									online. My next thing I like to do is go to the gym. I've been working out consistently for about 4 years 
									now ever since high school. The reason why I feel in love with lifting was because I played sports in high 
									school. So it became a hobby to do. I just love improving my mental health and physical health. My next 
									thing I like to do is listen to music. Some of my favorite genres of music is Hip-Hop/Rap, Country music, 
									Rock music, RNB and 80s Rock music. My next thing I like to do is work. I generally enjoy working and 
									making money to me it's a hobby. My next thing I like to do is spend time with family. I love spending time 
									with them especially with football season I love watching NFL and College football games with them. Some of 
									my favorite football teams are in college is Ohio State and in the NFL it is the Pittsburgh Steelers. What 
									I also like to do is watch Netflix shows I like to watch Stranger Things, Outer Banks, Wednesday and Beef. 
									Another thing I like to watch is Marvel movies some of my favorites are Avengers: Endgame, Avengers: 
									Infinity Wars, Spiderman: No Way Home, Guardians of the Galaxy Volume 1 and 3, Captain America: The Winter 
									Soldier and Thor: Ragnarok. I usually try to do these on my free time when I'm not working or doing school 
									work just to get a some time to myself because doing work or school work can be stressful at times so I have
									these to let loose on. As far as the future goes, my plan is become a web development since I love making 
									the website to me it just fasinating of what you can do with a website design. My plan is to take advantage 
									of the internship that WVNCC offers in our final semester and use that to land a job in web development or 
									to go to the Air Force for my bachlors degree so I don't go into debt.
									
									My task for Chipper: Front-end development - For the User Interface we are using HTML, CSS, Bootstrap and 
									JavaScript. I will be creating the website and UI of the Chipper website that allow users to access and 
									interact with the application.
								</p>
								<section>
									<header>
										<h3>Something else</h3>
									</header>
									<p>
										Elementum odio duis semper risus et lectus commodo fringilla. Maecenas sagittis convallis justo vel mattis.
										placerat, nunc diam iaculis massa, et aliquet nibh leo non nisl vitae porta lobortis, enim neque fringilla nunc,
										eget faucibus lacus sem quis nunc suspendisse nec lectus sit amet augue rutrum vulputate ut ut mi. Aenean
										elementum, mi sit amet porttitor lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor
										sit amet nullam consequat feugiat dolore tempus.
										Elementum odio duis semper risus et lectus commodo fringilla. Maecenas sagittis convallis justo vel mattis.
										placerat, nunc diam iaculis massa, et aliquet nibh leo non nisl vitae porta lobortis, enim neque fringilla nunc,
										eget faucibus lacus sem quis nunc suspendisse nec lectus sit amet augue rutrum vulputate ut ut mi. Aenean
										elementum, mi sit amet porttitor lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor.
									</p>
									<p>
										Nunc diam iaculis massa, et aliquet nibh leo non nisl vitae porta lobortis, enim neque fringilla nunc,
										eget faucibus lacus sem quis nunc suspendisse nec lectus sit amet augue rutrum vulputate ut ut mi. Aenean
										elementum, mi sit amet porttitor lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor
										sit amet nullam consequat feugiat dolore tempus.
									</p>
								</section>
								<section>
									<header>
										<h3>So in conclusion ...</h3>
									</header>
									<p>
										Nunc diam iaculis massa, et aliquet nibh leo non nisl vitae porta lobortis, enim neque fringilla nunc,
										eget faucibus lacus sem quis nunc suspendisse nec lectus sit amet augue rutrum vulputate ut ut mi. Aenean
										elementum, mi sit amet porttitor lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor
										sit amet nullam consequat feugiat dolore tempus. Elementum odio duis semper risus et lectus commodo fringilla.
										Maecenas sagittis convallis justo vel mattis.
									</p>
								</section>
							</article>

					</div>
				</section>