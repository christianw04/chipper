<!DOCTYPE HTML>
<!--
	Dopetrope by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Chipper</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">
			<?php
				include("header.php");
			?>
			<?php
				$webpageslist = array("home", "memegenerator", "cardgenerator", "populargenerated", "aboutus", "login", "createanaccount");
				if (isset($_GET['page'])){
					$page = $_GET['page'];
					if(in_array($page, $webpageslist)){
						include("$page.php");
					}else{
						include("404.php");
					}
				}else{
					include("home.php");
				}
			?>
			<?php
				include("footer.php");
			?>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>